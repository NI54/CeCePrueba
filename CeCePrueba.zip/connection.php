<?php

$connection= mysqli_connect("mysql.hostinger.com.ar","u389429516_admin","stalker","u389429516_test");

?>